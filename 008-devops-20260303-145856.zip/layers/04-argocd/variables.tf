variable "project_name" {
  description = "Optional project name inserted into the cluster name. When set, the cluster is named {environment}-{project_name}-eks (e.g. prod-sharedservices-eks). When empty, the cluster is named {environment}-eks."
  type        = string
  default     = ""
}

variable "aws_region" {
  description = "AWS region"
  type        = string
}

variable "domain" {
  description = "Base domain for ingress hostnames"
  type        = string
}

variable "acm_certificate_arn" {
  description = "ACM certificate ARN for TLS termination"
  type        = string
}

variable "chart_version" {
  description = "ArgoCD Helm chart version"
  type        = string
  default     = "9.4.1"
}

variable "namespace" {
  description = "Kubernetes namespace for ArgoCD"
  type        = string
  default     = "argocd"
}

variable "argocd_server_replicas" {
  description = "Number of ArgoCD server replicas"
  type        = number
  default     = 2
}

variable "environment" {
  description = "Deployment environment (dev, staging, prod)"
  type        = string
  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "Environment must be one of: dev, staging, prod."
  }
}

variable "git_repo_url" {
  description = "Git repository URL for ArgoCD app-of-apps (contains argocd/envs/)"
  type        = string
}

variable "git_target_revision" {
  description = "Git branch, tag, or commit for the app-of-apps source"
  type        = string
  default     = "HEAD"
}

# ── WAF ──────────────────────────────────────────────────────────────────────

variable "enable_waf" {
  description = "Whether to deploy a WAF Web ACL and associate it with the ALB"
  type        = bool
  default     = false
}

variable "waf_acl_arn" {
  description = "WAF Web ACL ARN to associate with the ALB (populated by WAF module output when enable_waf=true)"
  type        = string
  default     = ""
}

# ── OIDC / SSO ──────────────────────────────────────────────────────────────

variable "oidc_issuer_url" {
  description = "OIDC issuer URL for ArgoCD SSO (leave empty to disable SSO)"
  type        = string
  default     = ""
}

variable "oidc_client_id" {
  description = "OIDC client ID for ArgoCD SSO"
  type        = string
  default     = ""
}

variable "oidc_client_secret" {
  description = "OIDC client secret for ArgoCD SSO"
  type        = string
  default     = ""
  sensitive   = true
}

# ── SSH repo credentials ─────────────────────────────────────────────────────

variable "git_ssh_url_prefix" {
  description = "SSH URL prefix for credential matching (e.g. git@github.com:my-org)"
  type        = string
  default     = ""
}

variable "git_ssh_private_key" {
  description = "SSH private key for ArgoCD to authenticate with private Git repos"
  type        = string
  default     = ""
  sensitive   = true
}

variable "git_ssh_secret_name" {
  description = "AWS Secrets Manager secret name containing the SSH private key (takes precedence over git_ssh_private_key)"
  type        = string
  default     = ""
}

# ── Custom image ─────────────────────────────────────────────────────────────

variable "argocd_image_repository" {
  description = "Custom container image repository for ArgoCD (e.g. 123456789.dkr.ecr.us-east-1.amazonaws.com/argocd). Leave empty to use the chart default."
  type        = string
  default     = ""
}

variable "argocd_image_tag" {
  description = "Custom container image tag for ArgoCD. Only used when argocd_image_repository is set."
  type        = string
  default     = ""
}
