data "aws_secretsmanager_secret_version" "git_ssh_key" {
  count     = var.git_ssh_secret_name != "" ? 1 : 0
  secret_id = var.git_ssh_secret_name
}

locals {
  cluster_name        = var.project_name != "" ? "${var.environment}-${var.project_name}-eks" : "${var.environment}-eks"
  git_ssh_private_key = var.git_ssh_secret_name != "" ? data.aws_secretsmanager_secret_version.git_ssh_key[0].secret_string : var.git_ssh_private_key
}
