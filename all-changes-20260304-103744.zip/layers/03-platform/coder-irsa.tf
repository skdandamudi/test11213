# ── IAM role for Coder (IRSA) ────────────────────────────────────────────────
# Follows the external-secrets-irsa.tf pattern.
# Coder manages workspaces via K8s API, so no additional AWS permissions needed.

data "aws_iam_policy_document" "coder_assume_role" {
  count = var.coder_enabled ? 1 : 0

  statement {
    actions = ["sts:AssumeRoleWithWebIdentity"]
    effect  = "Allow"

    principals {
      type        = "Federated"
      identifiers = [data.aws_iam_openid_connect_provider.eks.arn]
    }

    condition {
      test     = "StringEquals"
      variable = "${replace(data.aws_eks_cluster.this.identity[0].oidc[0].issuer, "https://", "")}:aud"
      values   = ["sts.amazonaws.com"]
    }

    condition {
      test     = "StringEquals"
      variable = "${replace(data.aws_eks_cluster.this.identity[0].oidc[0].issuer, "https://", "")}:sub"
      values   = ["system:serviceaccount:coder:coder"]
    }
  }
}

resource "aws_iam_role" "coder" {
  count              = var.coder_enabled ? 1 : 0
  name               = "${local.cluster_name}-coder"
  assume_role_policy = data.aws_iam_policy_document.coder_assume_role[0].json
}
