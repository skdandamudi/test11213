terraform {
  required_version = ">= 1.14.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 3.0"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.0"
    }
  }

  # S3 bucket created by 00-tf-state-setup. Bucket, region, and key are
  # injected at init time via terraform.sh:
  #   key = devops/<env>/platform/terraform.tfstate
  backend "s3" {
    key            = "devops/platform/terraform.tfstate" # overridden by terraform.sh
    encrypt        = true
    dynamodb_table = ""
  }
}
