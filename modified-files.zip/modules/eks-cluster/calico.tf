# ─────────────────────────────────────────────────────────────────────────────
# Calico CNI — deployed via Tigera operator Helm chart
#
# Two modes:
#   policy-only : Keep VPC CNI for networking, use Calico for network policy
#   cni         : Replace VPC CNI entirely with Calico networking + policy
#
# CNI mode execution flow:
#   1. Cluster created — EKS auto-installs aws-node DaemonSet (self-managed VPC CNI)
#   2. VPC CNI managed addon NOT created (existing logic in main.tf)
#   3. Node group created — nodes join, self-managed aws-node runs, nodes become Ready
#   4. null_resource.remove_vpc_cni — kubectl deletes the aws-node DaemonSet
#   5. Calico Helm release — operator + calico-node replace VPC CNI
#
# Security groups: The EKS-managed cluster security group (auto-created by EKS)
# allows all traffic between nodes by default, which covers Calico encapsulation
# ports (VXLAN UDP/4789, IPIP protocol 4, BGP TCP/179) without extra rules.
# ─────────────────────────────────────────────────────────────────────────────

# ── Remove self-managed VPC CNI for Calico CNI mode ─────────────────────────
# EKS pre-installs the VPC CNI as a self-managed addon (aws-node DaemonSet in
# kube-system) on every new cluster. When using Calico as the CNI, this
# DaemonSet must be deleted before Calico is installed to avoid conflicts.
resource "null_resource" "remove_vpc_cni" {
  count = var.calico_enabled && var.calico_mode == "cni" ? 1 : 0

  provisioner "local-exec" {
    interpreter = ["bash", "-euo", "pipefail", "-c"]
    command     = <<-EOT
      aws eks update-kubeconfig \
        --name ${aws_eks_cluster.this.name} \
        --region ${data.aws_region.current.name} \
        --kubeconfig /tmp/kubeconfig-${aws_eks_cluster.this.name}
      export KUBECONFIG="/tmp/kubeconfig-${aws_eks_cluster.this.name}"
      echo "Waiting for nodes to become Ready..."
      kubectl wait --for=condition=Ready node --all --timeout=300s
      echo "Deleting aws-node DaemonSet..."
      kubectl delete daemonset aws-node -n kube-system --ignore-not-found=true
      rm -f /tmp/kubeconfig-${aws_eks_cluster.this.name}
      echo "VPC CNI (aws-node) removed successfully."
    EOT
  }

  triggers = {
    cluster_endpoint = aws_eks_cluster.this.endpoint
  }

  depends_on = [aws_eks_cluster.this, aws_eks_node_group.this]
}

locals {
  # Base installation config varies by Calico mode
  calico_installation_base = var.calico_mode == "policy-only" ? {
    kubernetesProvider = "EKS"
    cni                = { type = "AmazonVPC" }
    calicoNetwork      = { linuxPolicyOnly = true }
  } : {
    kubernetesProvider = "EKS"
    cni                = { type = "Calico" }
    calicoNetwork = {
      bgp = var.calico_encapsulation == "VXLAN" ? "Disabled" : "Enabled"
      ipPools = [{
        cidr          = var.calico_pod_cidr
        encapsulation = var.calico_encapsulation
      }]
    }
  }

  # Registry + pull secret overrides (merged into installation when set)
  calico_registry_overrides = merge(
    var.calico_image_registry != "" ? { registry = var.calico_image_registry } : {},
    length(var.calico_image_pull_secrets) > 0 ? {
      imagePullSecrets = [for s in var.calico_image_pull_secrets : { name = s }]
    } : {},
  )

  # Final Helm values map
  calico_values = merge(
    {
      installation = merge(local.calico_installation_base, local.calico_registry_overrides)
    },
    # Operator image registry (separate top-level key in chart values)
    var.calico_image_registry != "" ? {
      tigeraOperator = { registry = var.calico_image_registry }
    } : {},
  )
}

resource "helm_release" "calico" {
  count = var.calico_enabled ? 1 : 0

  name             = "calico"
  repository       = var.calico_chart_repository
  chart            = "tigera-operator"
  version          = var.calico_version
  namespace        = "tigera-operator"
  create_namespace = true

  values = [yamlencode(local.calico_values)]

  depends_on = [
    aws_eks_cluster.this,
    aws_eks_node_group.this,
    null_resource.remove_vpc_cni,
  ]
}
