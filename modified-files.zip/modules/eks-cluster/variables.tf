variable "cluster_name" {
  description = "Name of the EKS cluster"
  type        = string
}

variable "kubernetes_version" {
  description = "Kubernetes version for the EKS cluster"
  type        = string
  default     = "1.32"
}

# ── Compute mode ─────────────────────────────────────────────────────────────
# Three valid combinations:
#   automode=false  managed=true   → Managed only (self-managed addons + node group)
#   automode=true   managed=false  → Auto Mode only (AWS manages everything)
#   automode=true   managed=true   → Hybrid (Auto Mode + managed node group)

variable "automode_enabled" {
  description = "Enable EKS Auto Mode (AWS manages compute, networking addons, and storage)"
  type        = bool
  default     = false
}

variable "automode_node_pools" {
  description = "Node pool types for Auto Mode"
  type        = list(string)
  default     = ["general-purpose", "system"]
}

variable "managed_node_group_enabled" {
  description = "Create a managed node group. Can be combined with Auto Mode for hybrid compute."
  type        = bool
  default     = true
}

variable "karpenter_enabled" {
  description = "Provision Karpenter infrastructure (controller IAM role, instance profile, SQS queue, EventBridge rules). Requires managed_node_group_enabled for bootstrap capacity."
  type        = bool
  default     = false
}

# ── Endpoint access ──────────────────────────────────────────────────────────

variable "endpoint_public_access" {
  description = "Whether the EKS API server endpoint is publicly accessible"
  type        = bool
  default     = false
}

variable "public_access_cidrs" {
  description = "List of CIDR blocks allowed to access the EKS public API endpoint. Only used when endpoint_public_access is true."
  type        = list(string)
  default     = ["0.0.0.0/0"]
}

variable "private_access_cidrs" {
  description = "List of CIDR blocks (e.g. VPN) allowed to reach the EKS API server on port 443 via the private endpoint. Adds ingress rules to the cluster security group."
  type        = list(string)
  default     = []
}

# ── Cluster access ────────────────────────────────────────────────────────────

variable "access_entries" {
  description = "Map of IAM principal ARN to EKS access configuration. Key is the IAM role/user ARN. When namespaces is empty the policy applies cluster-wide."
  type = map(object({
    access_policy_arn = string
    namespaces        = optional(list(string), [])
  }))
  default = {}
}

# ── Encryption ───────────────────────────────────────────────────────────────

variable "cluster_encryption_kms_key_arn" {
  description = "KMS key ARN for encrypting Kubernetes secrets at rest. Leave empty to skip."
  type        = string
  default     = ""
}

# ── Networking ───────────────────────────────────────────────────────────────

variable "vpc_id" {
  description = "ID of the VPC where the EKS cluster will be created"
  type        = string
}

variable "subnet_ids" {
  description = "List of subnet IDs for the EKS cluster control plane and node groups"
  type        = list(string)
}

# ── Node group (requires managed_node_group_enabled) ────────────────────────

variable "node_instance_types" {
  description = "EC2 instance types for the managed node group"
  type        = list(string)
  default     = ["m5.xlarge"]
}

variable "node_desired_size" {
  description = "Desired number of nodes"
  type        = number
  default     = 2
}

variable "node_min_size" {
  description = "Minimum number of nodes"
  type        = number
  default     = 1
}

variable "node_max_size" {
  description = "Maximum number of nodes"
  type        = number
  default     = 5
}

variable "node_disk_size" {
  description = "Root EBS volume size in GiB for worker nodes"
  type        = number
  default     = 50
}

variable "node_ami_type" {
  description = "AMI type for the managed node group (AL2023_x86_64_STANDARD, AL2_x86_64, BOTTLEROCKET_x86_64)"
  type        = string
  default     = "AL2023_x86_64_STANDARD"
}

# ── Control plane logging ────────────────────────────────────────────────────

variable "cluster_log_types" {
  description = "EKS control plane log types to enable"
  type        = list(string)
  default     = ["api", "audit", "authenticator", "controllerManager", "scheduler"]
}

variable "cluster_log_retention_days" {
  description = "CloudWatch log retention in days for control plane logs"
  type        = number
  default     = 90
}

# ── VPC CNI (managed mode without Auto Mode only) ───────────────────────────

variable "vpc_cni_prefix_delegation" {
  description = "Enable VPC CNI prefix delegation for higher pod density (ignored when Auto Mode is enabled)"
  type        = bool
  default     = true
}

# ── Calico CNI ────────────────────────────────────────────────────────────────

variable "calico_enabled" {
  description = "Deploy Calico via Helm. When true, calico_mode controls the deployment model."
  type        = bool
  default     = false
}

variable "calico_mode" {
  description = "Calico deployment mode: 'policy-only' keeps VPC CNI for networking and uses Calico for network policy enforcement. 'cni' replaces VPC CNI entirely with Calico for both networking and policy. Note: 'cni' mode is incompatible with EKS Auto Mode and requires kubectl + aws CLI on the Terraform runner."
  type        = string
  default     = "policy-only"
  validation {
    condition     = contains(["policy-only", "cni"], var.calico_mode)
    error_message = "calico_mode must be 'policy-only' or 'cni'."
  }
}

variable "calico_version" {
  description = "Tigera Calico operator Helm chart version"
  type        = string
  default     = "3.29.3"
}

variable "calico_pod_cidr" {
  description = "Pod CIDR for Calico IPAM (only used when calico_mode = 'cni'). Must not overlap with VPC CIDR."
  type        = string
  default     = "192.168.0.0/16"
}

variable "calico_encapsulation" {
  description = "Calico encapsulation mode when calico_mode = 'cni': VXLAN, IPIP, or None"
  type        = string
  default     = "VXLAN"
  validation {
    condition     = contains(["VXLAN", "IPIP", "None"], var.calico_encapsulation)
    error_message = "calico_encapsulation must be 'VXLAN', 'IPIP', or 'None'."
  }
}

variable "calico_chart_repository" {
  description = "Helm chart repository URL for the Tigera operator. Defaults to the public chart repo. For ECR OCI registries, use oci:// prefix (e.g. oci://<account>.dkr.ecr.<region>.amazonaws.com)."
  type        = string
  default     = "https://docs.tigera.io/calico/charts"
}

variable "calico_image_registry" {
  description = "Custom container image registry for all Calico/Tigera images (operator + components). Overrides the default public registries. Use for ECR pull-through cache (e.g. <account>.dkr.ecr.<region>.amazonaws.com/quay)."
  type        = string
  default     = ""
}

variable "calico_image_pull_secrets" {
  description = "List of Kubernetes Secret names for pulling Calico images from a private registry. Not typically needed for ECR pull-through cache when nodes have IAM-based ECR access."
  type        = list(string)
  default     = []
}

# ── Tags ─────────────────────────────────────────────────────────────────────

variable "tags" {
  description = "Additional tags to apply to all resources"
  type        = map(string)
  default     = {}
}
