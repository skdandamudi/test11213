# eks-cluster Module

Reusable Terraform module that creates an EKS cluster with flexible compute modes, enhanced networking, CloudWatch observability, and optional Karpenter infrastructure.

## Compute Modes

The module supports four compute configurations controlled by three boolean variables:

| `automode_enabled` | `managed_node_group_enabled` | `karpenter_enabled` | Mode |
|---|---|---|---|
| `false` | `true` | `false` | **Managed only** — self-managed addons + EC2 node group |
| `true` | `false` | `false` | **Auto Mode only** — AWS fully manages compute, networking, storage |
| `true` | `true` | `false` | **Hybrid** — Auto Mode handles addons; EC2 node group for baseline capacity |
| `false` | `true` | `true` | **Managed + Karpenter** — managed node group bootstraps Karpenter for elastic scaling |

> Karpenter requires a managed node group (`managed_node_group_enabled = true`) to provide bootstrap capacity for the Karpenter controller pod.

## Resources Created

### Always created
- **EKS cluster** with private + public endpoints
- **Cluster IAM role** with `AmazonEKSClusterPolicy`, `AmazonEKSVPCResourceController`
- **Node IAM role** with `AmazonSSMManagedInstanceCore`, `CloudWatchAgentServerPolicy`
- **Cluster security group** with unrestricted egress
- **CloudWatch log group** (`/aws/eks/<cluster>/cluster`) with configurable retention
- **OIDC provider** for IRSA (IAM Roles for Service Accounts)
- **CloudWatch Observability addon** (Container Insights with container logs and metrics)

### Auto Mode (when `automode_enabled = true`)
- Cluster-level `compute_config`, `kubernetes_network_config` (elastic load balancing), `storage_config` (block storage)
- Cluster IAM policies: `AmazonEKSComputePolicy`, `AmazonEKSBlockStoragePolicy`, `AmazonEKSLoadBalancingPolicy`, `AmazonEKSNetworkingPolicy`
- Auto Mode manages vpc-cni, coredns, kube-proxy, and pod-identity-agent automatically

### Managed node group (when `managed_node_group_enabled = true`)
- **EKS managed node group** with configurable instance types, scaling, disk size, and AMI type
- Node IAM policies: `AmazonEKSWorkerNodePolicy`, `AmazonEKS_CNI_Policy`, `AmazonEC2ContainerRegistryReadOnly`
- `desired_size` changes are ignored in the lifecycle (for autoscaler compatibility)

### Self-managed addons (when `automode_enabled = false` AND `managed_node_group_enabled = true`)
- **vpc-cni** with prefix delegation and pod ENI support
- **coredns**
- **kube-proxy**
- **eks-pod-identity-agent**

### Pure Auto Mode node policies (when `automode_enabled = true` AND `managed_node_group_enabled = false`)
- Lighter-weight policies: `AmazonEKSWorkerNodeMinimalPolicy`, `AmazonEC2ContainerRegistryPullOnly`

### Karpenter infrastructure (when `karpenter_enabled = true`)
- **Karpenter controller IAM role** (IRSA) with scoped EC2, IAM, SSM, Pricing, and SQS permissions
- **Instance profile** for Karpenter-launched nodes (uses existing node IAM role)
- **EKS access entry** (`EC2_LINUX`) so Karpenter-launched nodes can join the cluster
- **SQS queue** for interruption handling (encrypted, 5-minute retention)
- **EventBridge rules** routing to SQS:
  - EC2 Spot Instance Interruption Warning
  - EC2 Instance Rebalance Recommendation
  - EC2 Instance State-change Notification
  - AWS Health Event (EC2)
- **Discovery tags** (`karpenter.sh/discovery`) on subnets and the cluster security group

> The Karpenter Helm chart is **not** installed by this module. Use the outputs below to configure a downstream Helm deployment.

## Usage

### Managed + Karpenter

```hcl
module "eks" {
  source = "../../modules/eks-cluster"

  cluster_name       = "my-cluster"
  kubernetes_version = "1.32"
  vpc_id             = "vpc-abc123"
  subnet_ids         = ["subnet-1", "subnet-2", "subnet-3"]

  # Compute mode
  automode_enabled           = false
  managed_node_group_enabled = true
  karpenter_enabled          = true

  # Node group sizing (bootstrap capacity for Karpenter controller)
  node_instance_types = ["m5.xlarge"]
  node_desired_size   = 2
  node_min_size       = 2
  node_max_size       = 3

  # Logging
  cluster_log_types          = ["api", "audit", "authenticator", "controllerManager", "scheduler"]
  cluster_log_retention_days = 90

  # Enhanced networking
  vpc_cni_prefix_delegation = true
}
```

### Deploying Karpenter Helm chart (downstream layer)

After applying this module, use the outputs to configure the Karpenter Helm release:

```hcl
resource "helm_release" "karpenter" {
  name       = "karpenter"
  repository = "oci://public.ecr.aws/karpenter"
  chart      = "karpenter"
  version    = "1.1.1"
  namespace  = "kube-system"

  set {
    name  = "settings.clusterName"
    value = module.eks.cluster_name
  }
  set {
    name  = "settings.clusterEndpoint"
    value = module.eks.cluster_endpoint
  }
  set {
    name  = "settings.interruptionQueue"
    value = module.eks.karpenter_queue_name
  }
  set {
    name  = "serviceAccount.annotations.eks\\.amazonaws\\.com/role-arn"
    value = module.eks.karpenter_controller_role_arn
  }
}
```

### Calico CNI mode (replaces VPC CNI)

```hcl
module "eks" {
  source = "../../modules/eks-cluster"

  cluster_name       = "my-cluster"
  kubernetes_version = "1.32"
  vpc_id             = "vpc-abc123"
  subnet_ids         = ["subnet-1", "subnet-2", "subnet-3"]

  # Compute mode — Auto Mode is NOT compatible with Calico CNI mode
  automode_enabled           = false
  managed_node_group_enabled = true

  # Calico CNI — replaces VPC CNI entirely
  calico_enabled       = true
  calico_mode          = "cni"
  calico_pod_cidr      = "192.168.0.0/16"
  calico_encapsulation = "VXLAN"

  node_instance_types = ["m5.xlarge"]
  node_desired_size   = 2
  node_min_size       = 2
  node_max_size       = 5
}
```

### Calico with ECR pull-through cache (air-gapped / private registry)

```hcl
module "eks" {
  source = "../../modules/eks-cluster"

  cluster_name       = "my-cluster"
  kubernetes_version = "1.32"
  vpc_id             = "vpc-abc123"
  subnet_ids         = ["subnet-1", "subnet-2", "subnet-3"]

  automode_enabled           = false
  managed_node_group_enabled = true

  # Calico with ECR pull-through cache
  calico_enabled          = true
  calico_mode             = "policy-only"
  calico_chart_repository = "oci://111122223333.dkr.ecr.us-east-1.amazonaws.com"
  calico_image_registry   = "111122223333.dkr.ecr.us-east-1.amazonaws.com/quay"

  node_instance_types = ["m5.xlarge"]
  node_desired_size   = 2
  node_min_size       = 2
  node_max_size       = 5
}
```

> When using ECR pull-through cache with IAM-based node access, `calico_image_pull_secrets` is typically not needed. Set it only when nodes lack native ECR credentials.

**Prerequisites for CNI mode:** The Terraform runner must have `kubectl` and `aws` CLI installed. IAM access is provided automatically via `bootstrap_cluster_creator_admin_permissions = true`.

**Execution flow:**
1. EKS cluster created — AWS auto-installs the `aws-node` DaemonSet (self-managed VPC CNI)
2. VPC CNI **managed addon** is skipped (no `aws_eks_addon.vpc_cni`)
3. Managed node group created — nodes join, `aws-node` runs, nodes become Ready
4. `null_resource.remove_vpc_cni` — deletes the `aws-node` DaemonSet via `kubectl`
5. Calico Helm release — Tigera operator installs `calico-node` as the replacement CNI

> **Auto Mode warning:** Calico CNI mode (`calico_mode = "cni"`) is incompatible with EKS Auto Mode (`automode_enabled = true`). Auto Mode manages the VPC CNI automatically and cannot be replaced. Use `calico_mode = "policy-only"` with Auto Mode instead.

### Managed only (default)

```hcl
module "eks" {
  source = "../../modules/eks-cluster"

  cluster_name       = "my-cluster"
  kubernetes_version = "1.32"
  vpc_id             = "vpc-abc123"
  subnet_ids         = ["subnet-1", "subnet-2", "subnet-3"]

  automode_enabled           = false
  managed_node_group_enabled = true

  node_instance_types = ["m5.xlarge"]
  node_desired_size   = 2
  node_min_size       = 1
  node_max_size       = 5

  cluster_log_types          = ["api", "audit", "authenticator", "controllerManager", "scheduler"]
  cluster_log_retention_days = 90
  vpc_cni_prefix_delegation  = true
}
```

## Variables

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `cluster_name` | `string` | — | Name of the EKS cluster |
| `kubernetes_version` | `string` | `"1.32"` | Kubernetes version |
| `automode_enabled` | `bool` | `false` | Enable EKS Auto Mode |
| `automode_node_pools` | `list(string)` | `["general-purpose", "system"]` | Node pool types for Auto Mode |
| `managed_node_group_enabled` | `bool` | `true` | Create a managed node group |
| `karpenter_enabled` | `bool` | `false` | Provision Karpenter infrastructure |
| `vpc_id` | `string` | — | VPC ID for the cluster |
| `subnet_ids` | `list(string)` | — | Subnet IDs for control plane and node groups |
| `node_instance_types` | `list(string)` | `["m5.xlarge"]` | EC2 instance types for managed node group |
| `node_desired_size` | `number` | `2` | Desired number of nodes |
| `node_min_size` | `number` | `1` | Minimum number of nodes |
| `node_max_size` | `number` | `5` | Maximum number of nodes |
| `node_disk_size` | `number` | `50` | Root EBS volume size (GiB) |
| `node_ami_type` | `string` | `"AL2023_x86_64_STANDARD"` | AMI type for managed node group |
| `cluster_log_types` | `list(string)` | `["api", "audit", "authenticator", "controllerManager", "scheduler"]` | Control plane log types |
| `cluster_log_retention_days` | `number` | `90` | CloudWatch log retention (days) |
| `vpc_cni_prefix_delegation` | `bool` | `true` | Enable VPC CNI prefix delegation (ignored when Auto Mode is on) |
| `calico_enabled` | `bool` | `false` | Deploy Calico via Helm |
| `calico_mode` | `string` | `"policy-only"` | Calico mode: `policy-only` or `cni` (CNI mode incompatible with Auto Mode) |
| `calico_version` | `string` | `"3.29.3"` | Tigera Calico operator Helm chart version |
| `calico_pod_cidr` | `string` | `"192.168.0.0/16"` | Pod CIDR for Calico IPAM (CNI mode only) |
| `calico_encapsulation` | `string` | `"VXLAN"` | Calico encapsulation: `VXLAN`, `IPIP`, or `None` |
| `calico_chart_repository` | `string` | `"https://docs.tigera.io/calico/charts"` | Helm chart repository URL for Tigera operator (use `oci://` prefix for ECR) |
| `calico_image_registry` | `string` | `""` | Custom image registry for all Calico/Tigera images (operator + components) |
| `calico_image_pull_secrets` | `list(string)` | `[]` | Kubernetes Secret names for pulling Calico images from a private registry |

## Outputs

| Name | Description |
|------|-------------|
| `cluster_name` | EKS cluster name |
| `cluster_endpoint` | EKS cluster API endpoint |
| `cluster_certificate_authority` | Base64-encoded cluster CA certificate |
| `cluster_security_group_id` | Security group ID attached to the cluster |
| `cluster_oidc_issuer_url` | OIDC issuer URL for IRSA |
| `oidc_provider_arn` | ARN of the OIDC provider |
| `node_group_name` | Managed node group name (`null` when disabled) |
| `node_role_arn` | IAM role ARN used by worker nodes |
| `automode_enabled` | Whether Auto Mode is enabled |
| `managed_node_group_enabled` | Whether a managed node group is created |
| `calico_enabled` | Whether Calico is deployed |
| `calico_mode` | Calico deployment mode (`null` when disabled) |
| `vpc_cni_removed` | Whether the VPC CNI was actively removed for Calico CNI mode |
| `karpenter_enabled` | Whether Karpenter infrastructure is provisioned |
| `karpenter_controller_role_arn` | Karpenter controller IAM role ARN (`null` when disabled) |
| `karpenter_instance_profile_name` | Instance profile for Karpenter nodes (`null` when disabled) |
| `karpenter_queue_name` | SQS interruption queue name (`null` when disabled) |

## Requirements

| Name | Version |
|------|---------|
| Terraform | >= 1.14.0 |
| AWS provider | ~> 6.0 |
| TLS provider | ~> 4.0 |
| `kubectl` | Required for Calico CNI mode (`calico_mode = "cni"`) |
| `aws` CLI | Required for Calico CNI mode (`calico_mode = "cni"`) |
