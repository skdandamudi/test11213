# ── ENIConfig for VPC CNI custom networking ───────────────────────────────────
# When the VPC CNI is configured with AWS_VPC_K8S_CNI_CUSTOM_NETWORK_CFG=true
# and ENI_CONFIG_LABEL_DEF=topology.kubernetes.io/zone, it reads ENIConfig
# resources to determine which subnet and security groups to use for pod ENIs
# in each availability zone.
#
# Each ENIConfig maps an AZ to a pod subnet (from a secondary VPC CIDR) so
# pods receive IPs from a dedicated range rather than the node subnet.
resource "kubernetes_manifest" "eniconfig" {
  for_each = var.calico_cni_mode ? {} : var.pod_subnet_ids

  manifest = {
    apiVersion = "crd.k8s.amazonaws.com/v1alpha1"
    kind       = "ENIConfig"
    metadata = {
      name = each.key
    }
    spec = {
      securityGroups = [data.aws_eks_cluster.this.vpc_config[0].cluster_security_group_id]
      subnet         = each.value
    }
  }
}

# ── VPC CNI addon update — enable custom networking ──────────────────────────
# Layer 02-eks installs the VPC CNI without custom networking flags because
# ENIConfig CRDs must exist first. After the ENIConfigs above are created,
# this resource updates the addon to enable custom networking.
resource "aws_eks_addon" "vpc_cni_custom_networking" {
  count        = !var.calico_cni_mode && length(var.pod_subnet_ids) > 0 ? 1 : 0
  cluster_name = data.aws_eks_cluster.this.name
  addon_name   = "vpc-cni"

  resolve_conflicts_on_create = "OVERWRITE"
  resolve_conflicts_on_update = "OVERWRITE"

  configuration_values = jsonencode({
    env = merge(
      {
        ENABLE_PREFIX_DELEGATION          = tostring(var.vpc_cni_prefix_delegation)
        WARM_PREFIX_TARGET                = "1"
        ENABLE_POD_ENI                    = "true"
        POD_SECURITY_GROUP_ENFORCING_MODE = "standard"
        AWS_VPC_K8S_CNI_CUSTOM_NETWORK_CFG = "true"
        ENI_CONFIG_LABEL_DEF               = "topology.kubernetes.io/zone"
      },
      var.vpc_cni_prefix_delegation ? {
        WARM_IP_TARGET    = "5"
        MINIMUM_IP_TARGET = "2"
      } : {}
    )
  })

  depends_on = [kubernetes_manifest.eniconfig]
}
