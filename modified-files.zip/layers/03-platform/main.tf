# ── KMS key for EBS volumes ──────────────────────────────────────────────────
module "kms_ebs" {
  source = "../../modules/kms-key"

  alias_name         = "alias/${local.cluster_name}-ebs"
  description        = "Encryption key for EBS volumes - ${local.cluster_name}"
  service_principals = ["ec2.amazonaws.com"]
}

# ── StorageClass ────────────────────────────────────────────────────────────
resource "kubernetes_storage_class_v1" "gp3_retain" {
  metadata {
    name = "gp3-retain"
  }

  storage_provisioner = "ebs.csi.aws.com"
  reclaim_policy      = "Retain"
  volume_binding_mode = "WaitForFirstConsumer"

  parameters = {
    type      = "gp3"
    encrypted = "true"
    fsType    = "ext4"
    kmsKeyId  = module.kms_ebs.key_id
  }

  allow_volume_expansion = true
}

# ── Namespaces ─────────────────────────────────────────────────────────────
resource "kubernetes_namespace_v1" "devops" {
  for_each = toset(local.all_namespaces)

  metadata {
    name = each.value

    labels = merge(
      {
        "app.kubernetes.io/managed-by" = "terraform"
        "purpose"                      = "devops"
      },
      {
        "pod-security.kubernetes.io/enforce" = var.pod_security_level
        "pod-security.kubernetes.io/warn"    = "restricted"
        "pod-security.kubernetes.io/audit"   = "restricted"
      }
    )
  }
}

# ── Persistent Volume Claims ───────────────────────────────────────────────

# Jenkins
module "pvc_jenkins_home" {
  count     = var.jenkins_enabled ? 1 : 0
  source    = "../../modules/persistent-volume-claim"
  name      = "jenkins-home"
  namespace = "jenkins"
  size      = "50Gi"
  labels = {
    "app.kubernetes.io/name" = "jenkins"
  }

  depends_on = [kubernetes_namespace_v1.devops]
}

# SonarQube
module "pvc_sonarqube_data" {
  count     = var.sonarqube_enabled ? 1 : 0
  source    = "../../modules/persistent-volume-claim"
  name      = "sonarqube-data"
  namespace = "sonarqube"
  size      = "30Gi"
  labels = {
    "app.kubernetes.io/name" = "sonarqube"
  }

  depends_on = [kubernetes_namespace_v1.devops]
}

# Nexus
module "pvc_nexus_data" {
  count     = var.nexus_enabled ? 1 : 0
  source    = "../../modules/persistent-volume-claim"
  name      = "nexus-data"
  namespace = "nexus"
  size      = "100Gi"
  labels = {
    "app.kubernetes.io/name" = "nexus"
  }

  depends_on = [kubernetes_namespace_v1.devops]
}

# Harbor — registry
module "pvc_harbor_registry" {
  count     = var.harbor_enabled ? 1 : 0
  source    = "../../modules/persistent-volume-claim"
  name      = "harbor-registry"
  namespace = "harbor"
  size      = "200Gi"
  labels = {
    "app.kubernetes.io/name"      = "harbor"
    "app.kubernetes.io/component" = "registry"
  }

  depends_on = [kubernetes_namespace_v1.devops]
}

# Harbor — database
module "pvc_harbor_database" {
  count     = var.harbor_enabled ? 1 : 0
  source    = "../../modules/persistent-volume-claim"
  name      = "harbor-database"
  namespace = "harbor"
  size      = "10Gi"
  labels = {
    "app.kubernetes.io/name"      = "harbor"
    "app.kubernetes.io/component" = "database"
  }

  depends_on = [kubernetes_namespace_v1.devops]
}

# Harbor — redis
module "pvc_harbor_redis" {
  count     = var.harbor_enabled ? 1 : 0
  source    = "../../modules/persistent-volume-claim"
  name      = "harbor-redis"
  namespace = "harbor"
  size      = "5Gi"
  labels = {
    "app.kubernetes.io/name"      = "harbor"
    "app.kubernetes.io/component" = "redis"
  }

  depends_on = [kubernetes_namespace_v1.devops]
}

# Harbor — jobservice
module "pvc_harbor_jobservice" {
  count     = var.harbor_enabled ? 1 : 0
  source    = "../../modules/persistent-volume-claim"
  name      = "harbor-jobservice"
  namespace = "harbor"
  size      = "10Gi"
  labels = {
    "app.kubernetes.io/name"      = "harbor"
    "app.kubernetes.io/component" = "jobservice"
  }

  depends_on = [kubernetes_namespace_v1.devops]
}

# Harbor — trivy
module "pvc_harbor_trivy" {
  count     = var.harbor_enabled ? 1 : 0
  source    = "../../modules/persistent-volume-claim"
  name      = "harbor-trivy"
  namespace = "harbor"
  size      = "10Gi"
  labels = {
    "app.kubernetes.io/name"      = "harbor"
    "app.kubernetes.io/component" = "trivy"
  }

  depends_on = [kubernetes_namespace_v1.devops]
}

# Monitoring — Prometheus data
module "pvc_prometheus_data" {
  count     = var.monitoring_enabled ? 1 : 0
  source    = "../../modules/persistent-volume-claim"
  name      = "prometheus-data"
  namespace = "monitoring"
  size      = "50Gi"
  labels = {
    "app.kubernetes.io/name" = "prometheus"
  }

  depends_on = [kubernetes_namespace_v1.devops]
}

# Monitoring — Grafana data
module "pvc_grafana_data" {
  count     = var.monitoring_enabled ? 1 : 0
  source    = "../../modules/persistent-volume-claim"
  name      = "grafana-data"
  namespace = "monitoring"
  size      = "10Gi"
  labels = {
    "app.kubernetes.io/name" = "grafana"
  }

  depends_on = [kubernetes_namespace_v1.devops]
}

# ── Network Policies ─────────────────────────────────────────────────────────

module "netpol_jenkins" {
  count  = var.enable_network_policies && var.jenkins_enabled ? 1 : 0
  source = "../../modules/namespace-network-policy"

  namespace                     = "jenkins"
  allow_ingress_from_namespaces = []

  depends_on = [kubernetes_namespace_v1.devops]
}

module "netpol_sonarqube" {
  count  = var.enable_network_policies && var.sonarqube_enabled ? 1 : 0
  source = "../../modules/namespace-network-policy"

  namespace = "sonarqube"
  allow_ingress_from_namespaces = [
    for ns in ["jenkins"] : ns if contains(local.all_namespaces, ns)
  ]

  depends_on = [kubernetes_namespace_v1.devops]
}

module "netpol_nexus" {
  count  = var.enable_network_policies && var.nexus_enabled ? 1 : 0
  source = "../../modules/namespace-network-policy"

  namespace = "nexus"
  allow_ingress_from_namespaces = [
    for ns in ["jenkins"] : ns if contains(local.all_namespaces, ns)
  ]

  depends_on = [kubernetes_namespace_v1.devops]
}

module "netpol_harbor" {
  count  = var.enable_network_policies && var.harbor_enabled ? 1 : 0
  source = "../../modules/namespace-network-policy"

  namespace = "harbor"
  allow_ingress_from_namespaces = [
    for ns in ["jenkins"] : ns if contains(local.all_namespaces, ns)
  ]

  depends_on = [kubernetes_namespace_v1.devops]
}

module "netpol_velero" {
  count  = var.enable_network_policies && var.velero_enabled ? 1 : 0
  source = "../../modules/namespace-network-policy"

  namespace                     = "velero"
  allow_ingress_from_namespaces = []

  depends_on = [kubernetes_namespace_v1.devops]
}

module "netpol_argocd" {
  count  = var.enable_network_policies ? 1 : 0
  source = "../../modules/namespace-network-policy"

  namespace = "argocd"
  allow_ingress_from_namespaces = [
    for ns in ["jenkins", "sonarqube", "nexus", "harbor", "velero"]
    : ns if contains(local.all_namespaces, ns)
  ]

  depends_on = [kubernetes_namespace_v1.devops]
}

module "netpol_monitoring" {
  count  = var.enable_network_policies && var.monitoring_enabled ? 1 : 0
  source = "../../modules/namespace-network-policy"

  namespace = "monitoring"
  allow_ingress_from_namespaces = [
    for ns in ["jenkins", "sonarqube", "nexus", "harbor", "velero", "argocd"]
    : ns if contains(local.all_namespaces, ns)
  ]

  depends_on = [kubernetes_namespace_v1.devops]
}

module "netpol_coder" {
  count  = var.enable_network_policies && var.coder_enabled ? 1 : 0
  source = "../../modules/namespace-network-policy"

  namespace                     = "coder"
  allow_ingress_from_namespaces = ["argocd"]

  depends_on = [kubernetes_namespace_v1.devops]
}

# ── Resource Quotas and Limit Ranges ─────────────────────────────────────────

module "governance" {
  for_each = var.namespace_quotas
  source   = "../../modules/namespace-governance"

  namespace              = each.key
  cpu_requests           = each.value.cpu_requests
  cpu_limits             = each.value.cpu_limits
  memory_requests        = each.value.memory_requests
  memory_limits          = each.value.memory_limits
  max_pods               = each.value.max_pods
  default_cpu_request    = each.value.default_cpu_request
  default_cpu_limit      = each.value.default_cpu_limit
  default_memory_request = each.value.default_memory_request
  default_memory_limit   = each.value.default_memory_limit

  depends_on = [kubernetes_namespace_v1.devops]
}
