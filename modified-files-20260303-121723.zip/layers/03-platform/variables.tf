variable "project_name" {
  description = "Optional project name inserted into the cluster name. When set, the cluster is named {environment}-{project_name}-eks (e.g. prod-sharedservices-eks). When empty, the cluster is named {environment}-eks."
  type        = string
  default     = ""
}

variable "aws_region" {
  description = "AWS region"
  type        = string
}

variable "environment" {
  description = "Deployment environment (dev, staging, prod)"
  type        = string
  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "Environment must be one of: dev, staging, prod."
  }
}

# ── Component toggles ────────────────────────────────────────────────────────

variable "jenkins_enabled" {
  description = "Deploy Jenkins PVC, Pod Identity roles, ECR push policy, and network policy"
  type        = bool
  default     = false
}

variable "sonarqube_enabled" {
  description = "Deploy SonarQube PVC and network policy"
  type        = bool
  default     = false
}

variable "nexus_enabled" {
  description = "Deploy Nexus PVC and network policy"
  type        = bool
  default     = false
}

variable "harbor_enabled" {
  description = "Deploy Harbor PVCs and network policy"
  type        = bool
  default     = false
}

variable "velero_enabled" {
  description = "Deploy Velero S3 bucket, KMS key, IRSA role, and network policy"
  type        = bool
  default     = false
}

variable "external_dns_enabled" {
  description = "Deploy ExternalDNS IRSA role"
  type        = bool
  default     = false
}

variable "external_secrets_enabled" {
  description = "Deploy External Secrets Operator IRSA role"
  type        = bool
  default     = false
}

variable "monitoring_enabled" {
  description = "Deploy Prometheus and Grafana PVCs and network policy"
  type        = bool
  default     = false
}

variable "extra_namespaces" {
  description = "Additional namespaces to create beyond those managed by component flags"
  type        = list(string)
  default     = []
}

variable "velero_backup_bucket_name" {
  description = "S3 bucket name for Velero backups (required when velero_enabled = true)"
  type        = string
  default     = ""
}

# ── Pod Security Standards ───────────────────────────────────────────────────

variable "pod_security_level" {
  description = "Pod Security Standards enforcement level (privileged, baseline, restricted)"
  type        = string
  default     = "baseline"
}

# ── Network Policies ─────────────────────────────────────────────────────────

variable "enable_network_policies" {
  description = "Whether to deploy namespace network isolation policies"
  type        = bool
  default     = true
}

# ── Resource Quotas ──────────────────────────────────────────────────────────

variable "namespace_quotas" {
  description = "Per-namespace resource quotas"
  type = map(object({
    cpu_requests           = string
    cpu_limits             = string
    memory_requests        = string
    memory_limits          = string
    max_pods               = number
    default_cpu_request    = optional(string, "100m")
    default_cpu_limit      = optional(string, "500m")
    default_memory_request = optional(string, "128Mi")
    default_memory_limit   = optional(string, "512Mi")
  }))
  default = {}
}

# ── Jenkins agent Pod Identity ───────────────────────────────────────────────

# ── Per-namespace CloudWatch log groups ───────────────────────────────────────

variable "app_log_retention_days" {
  description = "CloudWatch log retention in days for per-application log groups"
  type        = number
  default     = 30
}

# ── Jenkins agent Pod Identity ───────────────────────────────────────────────

variable "jenkins_ecr_repo_prefix" {
  description = "Prefix for Jenkins agent ECR repository names"
  type        = string
  default     = "jenkins-agent"
}

# ── Jenkins agent Pod Identity role mapping ─────────────────────────────────
#
# Each key creates a service account (jenkins-agent-<key>) and IAM role
# (<cluster>-jenkins-<key>).
#
# These do NOT map 1:1 to ECR repos in 01-bootstrap:
#
#   Role        ECR Image       Notes
#   ─────────── ─────────────── ──────────────────────────────────────────
#   default     (none)          Uses upstream jenkins/inbound-agent
#   maven       (none)          Uses upstream maven image
#   gradle      (none)          Uses upstream gradle image
#   node        jenkins-agent-node
#   python      jenkins-agent-python
#   terraform   jenkins-agent-terraform
#   kaniko      (none)          Uses gcr.io/kaniko-project/executor
#
# ECR-only (no pod identity role):
#   (n/a)       jenkins-agent-base       Build parent for node, terraform
#   (n/a)       jenkins-agent-base-ssh   SSH variant build parent
#   (n/a)       jenkins-agent-docker     Extends python, used in compose
#
variable "jenkins_agent_roles" {
  description = "Map of Jenkins agent types to their Pod Identity configuration. Each key becomes a service account (jenkins-agent-<key>) and an IAM role (<cluster>-jenkins-<key>)."
  type = map(object({
    managed_policy_arns = optional(list(string), [])
  }))
  default = {
    default   = {}
    maven     = {}
    gradle    = {}
    node      = {}
    python    = {}
    terraform = {}
    kaniko    = {}
  }
}

# ── Coder ────────────────────────────────────────────────────────────────────

variable "coder_enabled" {
  description = "Deploy Coder RDS database and IRSA role. When true, also add 'coder' to the namespaces list."
  type        = bool
  default     = false
}

variable "coder_db_connection_url" {
  description = "Existing PostgreSQL connection URL for Coder (postgres://user:pass@host:port/db). When set, skips RDS provisioning and stores this URL in Secrets Manager instead."
  type        = string
  default     = ""
  sensitive   = true
}

variable "coder_kms_key_arn" {
  description = "ARN of an existing KMS key for Coder RDS encryption. When empty, a new key is created."
  type        = string
  default     = ""
}

variable "coder_db_instance_class" {
  description = "RDS instance class for Coder PostgreSQL (ignored when coder_db_connection_url is set)"
  type        = string
  default     = "db.t4g.medium"
}

variable "coder_db_allocated_storage" {
  description = "Allocated storage in GB for Coder RDS (ignored when coder_db_connection_url is set)"
  type        = number
  default     = 20
}

variable "coder_db_max_allocated_storage" {
  description = "Maximum storage autoscaling limit in GB (ignored when coder_db_connection_url is set)"
  type        = number
  default     = 100
}

variable "coder_db_multi_az" {
  description = "Enable Multi-AZ for Coder RDS (ignored when coder_db_connection_url is set)"
  type        = bool
  default     = false
}

variable "coder_db_backup_retention_period" {
  description = "Number of days to retain RDS backups (ignored when coder_db_connection_url is set)"
  type        = number
  default     = 7
}
