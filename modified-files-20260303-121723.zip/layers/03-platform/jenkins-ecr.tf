# ── ECR push policy for Kaniko agent ────────────────────────────────────────
# ECR repositories are created in 01-bootstrap. This file only manages the
# IAM policy that allows the kaniko agent to push images.
#
# The repo list is discovered dynamically via aws_ecr_repositories so it
# stays in sync with 01-bootstrap without duplicating the image list.

data "aws_ecr_repositories" "jenkins_agent" {
  count = var.jenkins_enabled ? 1 : 0
}

locals {
  jenkins_ecr_repos = var.jenkins_enabled ? [
    for name in data.aws_ecr_repositories.jenkins_agent[0].names
    : name if startswith(name, "${var.jenkins_ecr_repo_prefix}-")
  ] : []
}

data "aws_ecr_repository" "jenkins_agent" {
  for_each = toset(local.jenkins_ecr_repos)
  name     = each.key
}

data "aws_iam_policy_document" "ecr_push" {
  count = var.jenkins_enabled ? 1 : 0

  statement {
    sid    = "ECRGetAuth"
    effect = "Allow"
    actions = [
      "ecr:GetAuthorizationToken",
    ]
    resources = ["*"]
  }

  statement {
    sid    = "ECRPushPull"
    effect = "Allow"
    actions = [
      "ecr:BatchCheckLayerAvailability",
      "ecr:PutImage",
      "ecr:InitiateLayerUpload",
      "ecr:UploadLayerPart",
      "ecr:CompleteLayerUpload",
      "ecr:GetDownloadUrlForLayer",
      "ecr:BatchGetImage",
    ]
    resources = [
      for repo in data.aws_ecr_repository.jenkins_agent : repo.arn
    ]
  }
}

resource "aws_iam_policy" "kaniko_ecr_push" {
  count  = var.jenkins_enabled ? 1 : 0
  name   = "${local.cluster_name}-kaniko-ecr-push"
  policy = data.aws_iam_policy_document.ecr_push[0].json

  tags = {
    "jenkins/agent-type" = "kaniko"
  }
}

resource "aws_iam_role_policy_attachment" "kaniko_ecr_push" {
  count      = var.jenkins_enabled ? 1 : 0
  role       = aws_iam_role.jenkins_agent["kaniko"].name
  policy_arn = aws_iam_policy.kaniko_ecr_push[0].arn
}
