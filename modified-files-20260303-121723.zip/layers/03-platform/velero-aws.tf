data "aws_caller_identity" "current" {}

# ── KMS key for Velero backups ───────────────────────────────────────────────
module "kms_velero" {
  count  = var.velero_enabled ? 1 : 0
  source = "../../modules/kms-key"

  alias_name         = "alias/${local.cluster_name}-velero-backups"
  description        = "Encryption key for Velero backup bucket - ${local.cluster_name}"
  service_principals = ["s3.amazonaws.com"]
}

# ── S3 bucket for Velero backups ─────────────────────────────────────────────
resource "aws_s3_bucket" "velero_backups" {
  count  = var.velero_enabled ? 1 : 0
  bucket = var.velero_backup_bucket_name

  lifecycle {
    precondition {
      condition     = var.velero_backup_bucket_name != ""
      error_message = "velero_backup_bucket_name is required when velero_enabled = true."
    }
  }
}

resource "aws_s3_bucket_versioning" "velero_backups" {
  count  = var.velero_enabled ? 1 : 0
  bucket = aws_s3_bucket.velero_backups[0].id

  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "velero_backups" {
  count  = var.velero_enabled ? 1 : 0
  bucket = aws_s3_bucket.velero_backups[0].id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = module.kms_velero[0].key_arn
    }
    bucket_key_enabled = true
  }
}

resource "aws_s3_bucket_public_access_block" "velero_backups" {
  count  = var.velero_enabled ? 1 : 0
  bucket = aws_s3_bucket.velero_backups[0].id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_lifecycle_configuration" "velero_backups" {
  count  = var.velero_enabled ? 1 : 0
  bucket = aws_s3_bucket.velero_backups[0].id

  rule {
    id     = "expire-old-backups"
    status = "Enabled"

    expiration {
      days = 90
    }

    noncurrent_version_expiration {
      noncurrent_days = 30
    }
  }
}

# ── IAM role for Velero (IRSA) ───────────────────────────────────────────────
data "aws_iam_policy_document" "velero_assume_role" {
  count = var.velero_enabled ? 1 : 0

  statement {
    actions = ["sts:AssumeRoleWithWebIdentity"]
    effect  = "Allow"

    principals {
      type        = "Federated"
      identifiers = [data.aws_eks_cluster.this.identity[0].oidc[0].issuer]
    }

    condition {
      test     = "StringEquals"
      variable = "${replace(data.aws_eks_cluster.this.identity[0].oidc[0].issuer, "https://", "")}:sub"
      values   = ["system:serviceaccount:velero:velero-server"]
    }
  }
}

resource "aws_iam_role" "velero" {
  count              = var.velero_enabled ? 1 : 0
  name               = "velero-${local.cluster_name}"
  assume_role_policy = data.aws_iam_policy_document.velero_assume_role[0].json
}

data "aws_iam_policy_document" "velero" {
  count = var.velero_enabled ? 1 : 0

  statement {
    sid    = "S3Access"
    effect = "Allow"
    actions = [
      "s3:GetObject",
      "s3:PutObject",
      "s3:DeleteObject",
      "s3:ListBucket",
      "s3:GetBucketLocation",
    ]
    resources = [
      aws_s3_bucket.velero_backups[0].arn,
      "${aws_s3_bucket.velero_backups[0].arn}/*",
    ]
  }

  statement {
    sid    = "EC2Snapshots"
    effect = "Allow"
    actions = [
      "ec2:DescribeVolumes",
      "ec2:DescribeSnapshots",
      "ec2:DescribeTags",
      "ec2:CreateTags",
      "ec2:CreateSnapshot",
      "ec2:DeleteSnapshot",
    ]
    resources = ["*"]
  }

  statement {
    sid    = "KMSAccess"
    effect = "Allow"
    actions = [
      "kms:GenerateDataKey*",
      "kms:Decrypt",
    ]
    resources = [module.kms_velero[0].key_arn]
  }
}

resource "aws_iam_role_policy" "velero" {
  count  = var.velero_enabled ? 1 : 0
  name   = "velero-policy"
  role   = aws_iam_role.velero[0].id
  policy = data.aws_iam_policy_document.velero[0].json
}
