# ── IAM role for External Secrets Operator (IRSA) ────────────────────────────
data "aws_iam_policy_document" "external_secrets_assume_role" {
  count = var.external_secrets_enabled ? 1 : 0

  statement {
    actions = ["sts:AssumeRoleWithWebIdentity"]
    effect  = "Allow"

    principals {
      type        = "Federated"
      identifiers = [data.aws_eks_cluster.this.identity[0].oidc[0].issuer]
    }

    condition {
      test     = "StringEquals"
      variable = "${replace(data.aws_eks_cluster.this.identity[0].oidc[0].issuer, "https://", "")}:sub"
      values   = ["system:serviceaccount:kube-system:external-secrets"]
    }
  }
}

resource "aws_iam_role" "external_secrets" {
  count              = var.external_secrets_enabled ? 1 : 0
  name               = "${local.cluster_name}-external-secrets"
  assume_role_policy = data.aws_iam_policy_document.external_secrets_assume_role[0].json
}

data "aws_iam_policy_document" "external_secrets" {
  count = var.external_secrets_enabled ? 1 : 0

  statement {
    sid    = "SecretsManagerAccess"
    effect = "Allow"
    actions = [
      "secretsmanager:GetSecretValue",
      "secretsmanager:DescribeSecret",
    ]
    resources = [
      "arn:aws:secretsmanager:${var.aws_region}:${data.aws_caller_identity.current.account_id}:secret:${local.cluster_name}/*",
    ]
  }
}

resource "aws_iam_role_policy" "external_secrets" {
  count  = var.external_secrets_enabled ? 1 : 0
  name   = "external-secrets-policy"
  role   = aws_iam_role.external_secrets[0].id
  policy = data.aws_iam_policy_document.external_secrets[0].json
}
