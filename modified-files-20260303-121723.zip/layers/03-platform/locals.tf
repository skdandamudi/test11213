locals {
  cluster_name = var.project_name != "" ? "${var.environment}-${var.project_name}-eks" : "${var.environment}-eks"

  all_namespaces = distinct(concat(
    ["argocd"],
    var.jenkins_enabled ? ["jenkins"] : [],
    var.sonarqube_enabled ? ["sonarqube"] : [],
    var.nexus_enabled ? ["nexus"] : [],
    var.harbor_enabled ? ["harbor"] : [],
    var.velero_enabled ? ["velero"] : [],
    var.monitoring_enabled ? ["monitoring"] : [],
    var.coder_enabled ? ["coder"] : [],
    var.extra_namespaces,
  ))
}
