locals {
  app_log_group_prefix = "/aws/eks/${local.cluster_name}/apps"

  # Managed namespaces + system namespaces that generate logs
  log_group_namespaces = concat(local.all_namespaces, ["kube-system", "default", "amazon-cloudwatch"])
}

resource "aws_cloudwatch_log_group" "app" {
  for_each = toset(local.log_group_namespaces)

  name              = "${local.app_log_group_prefix}/${each.value}"
  retention_in_days = var.app_log_retention_days
}
