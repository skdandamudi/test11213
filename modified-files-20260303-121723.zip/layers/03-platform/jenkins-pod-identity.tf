# ── Jenkins agent Pod Identity ───────────────────────────────────────────────
# Creates a dedicated IAM role, Kubernetes service account, and EKS Pod
# Identity Association for each Jenkins worker pod template.
#
# IAM policies are intentionally left empty — attach your own policies to
# each role based on what that agent type needs (e.g. terraform agent needs
# broad AWS access, kaniko agent needs ECR push).

locals {
  jenkins_namespace = "jenkins"
}

# ── IAM trust policy for EKS Pod Identity ────────────────────────────────────
data "aws_iam_policy_document" "pod_identity_trust" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole", "sts:TagSession"]

    principals {
      type        = "Service"
      identifiers = ["pods.eks.amazonaws.com"]
    }
  }
}

# ── IAM roles ────────────────────────────────────────────────────────────────
resource "aws_iam_role" "jenkins_agent" {
  for_each = var.jenkins_enabled ? var.jenkins_agent_roles : {}

  name               = "${local.cluster_name}-jenkins-${each.key}"
  assume_role_policy = data.aws_iam_policy_document.pod_identity_trust.json

  tags = {
    "jenkins/agent-type" = each.key
    "eks/cluster"        = local.cluster_name
  }
}

# ── Attach managed policies (when specified) ─────────────────────────────────
resource "aws_iam_role_policy_attachment" "jenkins_agent" {
  for_each = {
    for pair in flatten([
      for agent, cfg in (var.jenkins_enabled ? var.jenkins_agent_roles : {}) : [
        for idx, arn in cfg.managed_policy_arns : {
          key        = "${agent}-${idx}"
          role       = agent
          policy_arn = arn
        }
      ]
    ]) : pair.key => pair
  }

  role       = aws_iam_role.jenkins_agent[each.value.role].name
  policy_arn = each.value.policy_arn
}

# ── Kubernetes service accounts ──────────────────────────────────────────────
resource "kubernetes_service_account_v1" "jenkins_agent" {
  for_each = var.jenkins_enabled ? var.jenkins_agent_roles : {}

  metadata {
    name      = "jenkins-agent-${each.key}"
    namespace = local.jenkins_namespace

    labels = {
      "app.kubernetes.io/managed-by" = "terraform"
      "app.kubernetes.io/component"  = "jenkins-agent"
      "jenkins/agent-type"           = each.key
    }
  }

  depends_on = [kubernetes_namespace_v1.devops]
}

# ── EKS Pod Identity Associations ────────────────────────────────────────────
resource "aws_eks_pod_identity_association" "jenkins_agent" {
  for_each = var.jenkins_enabled ? var.jenkins_agent_roles : {}

  cluster_name    = local.cluster_name
  namespace       = local.jenkins_namespace
  service_account = kubernetes_service_account_v1.jenkins_agent[each.key].metadata[0].name
  role_arn        = aws_iam_role.jenkins_agent[each.key].arn
}
