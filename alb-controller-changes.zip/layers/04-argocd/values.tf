locals {
  helm_values = [
    yamlencode({
      server = {
        replicas = var.argocd_server_replicas

        insecure = true

        pdb = {
          enabled      = true
          minAvailable = 1
        }

        topologySpreadConstraints = [
          {
            maxSkew            = 1
            topologyKey        = "kubernetes.io/hostname"
            whenUnsatisfiable  = "DoNotSchedule"
            labelSelector = {
              matchLabels = {
                "app.kubernetes.io/component" = "server"
              }
            }
          }
        ]

        ingress = {
          enabled          = true
          ingressClassName = "alb"
          hostname         = "argocd.${var.domain}"

          annotations = merge(
            {
              "alb.ingress.kubernetes.io/scheme"               = "internet-facing"
              "alb.ingress.kubernetes.io/target-type"          = "ip"
              "alb.ingress.kubernetes.io/group.name"           = "devops-tools"
              "alb.ingress.kubernetes.io/group.order"          = "50"
              "alb.ingress.kubernetes.io/listen-ports"         = "[{\"HTTPS\": 443}]"
              "alb.ingress.kubernetes.io/certificate-arn"      = var.acm_certificate_arn
              "alb.ingress.kubernetes.io/ssl-policy"           = "ELBSecurityPolicy-TLS13-1-2-2021-06"
              "alb.ingress.kubernetes.io/healthcheck-path"     = "/healthz"
              "alb.ingress.kubernetes.io/healthcheck-protocol" = "HTTP"
              "alb.ingress.kubernetes.io/ssl-redirect"         = "443"
            },
            var.enable_waf ? {
              "alb.ingress.kubernetes.io/wafv2-acl-arn" = local.resolved_waf_acl_arn
            } : {}
          )
        }
      }

      repoServer = {
        replicas = 2
        pdb = {
          enabled      = true
          minAvailable = 1
        }
      }

      applicationSet = {
        replicas = 2
      }

      configs = {
        params = {
          "server.insecure" = true
        }
        cm = var.oidc_issuer_url != "" ? {
          url             = "https://argocd.${var.domain}"
          "oidc.config"   = yamlencode({
            name            = "SSO"
            issuer          = var.oidc_issuer_url
            clientID        = var.oidc_client_id
            clientSecret    = "$oidc.clientSecret"
            requestedScopes = ["openid", "profile", "email", "groups"]
          })
        } : {}
        secret = var.oidc_issuer_url != "" ? {
          extra = {
            "oidc.clientSecret" = var.oidc_client_secret
          }
        } : {}
        rbac = var.oidc_issuer_url != "" ? {
          "policy.csv" = <<-CSV
            g, devops-admins, role:admin
            g, devops-readonly, role:readonly
            p, role:deployer, applications, sync, */*, allow
            p, role:deployer, applications, get, */*, allow
            g, devops-deployers, role:deployer
          CSV
          "policy.default" = "role:readonly"
          scopes           = "[groups]"
        } : {}
      }
    })
  ]
}
