output "storage_class_name" {
  description = "Name of the gp3-retain StorageClass"
  value       = kubernetes_storage_class_v1.gp3_retain.metadata[0].name
}

output "namespaces" {
  description = "Created namespace names"
  value       = [for ns in kubernetes_namespace_v1.devops : ns.metadata[0].name]
}

# Coder outputs
output "coder_rds_endpoint" {
  description = "RDS endpoint for Coder PostgreSQL (null when using existing RDS)"
  value       = local.coder_create_rds ? aws_db_instance.coder[0].endpoint : null
}

output "coder_rds_secret_arn" {
  description = "Secrets Manager ARN containing Coder DB URL"
  value       = var.coder_enabled ? aws_secretsmanager_secret.coder_db_url[0].arn : null
}

output "coder_iam_role_arn" {
  description = "IAM role ARN for Coder IRSA"
  value       = var.coder_enabled ? aws_iam_role.coder[0].arn : null
}

# PVC outputs
output "pvc_jenkins_home" {
  description = "Jenkins home PVC name"
  value       = var.jenkins_enabled ? module.pvc_jenkins_home[0].pvc_name : null
}

output "pvc_sonarqube_data" {
  description = "SonarQube data PVC name"
  value       = var.sonarqube_enabled ? module.pvc_sonarqube_data[0].pvc_name : null
}

output "pvc_nexus_data" {
  description = "Nexus data PVC name"
  value       = var.nexus_enabled ? module.pvc_nexus_data[0].pvc_name : null
}

output "pvc_harbor_registry" {
  description = "Harbor registry PVC name"
  value       = var.harbor_enabled ? module.pvc_harbor_registry[0].pvc_name : null
}

output "pvc_harbor_database" {
  description = "Harbor database PVC name"
  value       = var.harbor_enabled ? module.pvc_harbor_database[0].pvc_name : null
}

output "pvc_harbor_redis" {
  description = "Harbor redis PVC name"
  value       = var.harbor_enabled ? module.pvc_harbor_redis[0].pvc_name : null
}

output "pvc_harbor_jobservice" {
  description = "Harbor jobservice PVC name"
  value       = var.harbor_enabled ? module.pvc_harbor_jobservice[0].pvc_name : null
}

output "pvc_harbor_trivy" {
  description = "Harbor trivy PVC name"
  value       = var.harbor_enabled ? module.pvc_harbor_trivy[0].pvc_name : null
}

# Monitoring PVC outputs
output "pvc_prometheus_data" {
  description = "Prometheus data PVC name"
  value       = var.monitoring_enabled ? module.pvc_prometheus_data[0].pvc_name : null
}

output "pvc_grafana_data" {
  description = "Grafana data PVC name"
  value       = var.monitoring_enabled ? module.pvc_grafana_data[0].pvc_name : null
}

# KMS outputs
output "kms_ebs_key_arn" {
  description = "KMS key ARN for EBS encryption"
  value       = module.kms_ebs.key_arn
}

output "kms_velero_key_arn" {
  description = "KMS key ARN for Velero backups"
  value       = var.velero_enabled ? module.kms_velero[0].key_arn : null
}

# Velero AWS outputs
output "velero_backup_bucket_name" {
  description = "S3 bucket name for Velero backups"
  value       = var.velero_enabled ? aws_s3_bucket.velero_backups[0].id : null
}

output "velero_iam_role_arn" {
  description = "IAM role ARN for Velero IRSA"
  value       = var.velero_enabled ? aws_iam_role.velero[0].arn : null
}

output "alb_controller_iam_role_arn" {
  description = "IAM role ARN for AWS Load Balancer Controller IRSA"
  value       = var.alb_controller_enabled ? aws_iam_role.alb_controller[0].arn : null
}

# ── Per-namespace CloudWatch log groups ───────────────────────────────────────

output "app_log_group_arns" {
  description = "Map of namespace to CloudWatch log group ARN"
  value       = { for ns, lg in aws_cloudwatch_log_group.app : ns => lg.arn }
}

output "app_log_group_prefix" {
  description = "CloudWatch log group prefix for per-app logs"
  value       = local.app_log_group_prefix
}

# Jenkins agent Pod Identity outputs
output "jenkins_agent_role_arns" {
  description = "Map of Jenkins agent type to IAM role ARN"
  value       = var.jenkins_enabled ? { for k, v in aws_iam_role.jenkins_agent : k => v.arn } : {}
}

output "jenkins_agent_service_accounts" {
  description = "Map of Jenkins agent type to Kubernetes service account name"
  value       = var.jenkins_enabled ? { for k, v in kubernetes_service_account_v1.jenkins_agent : k => v.metadata[0].name } : {}
}
