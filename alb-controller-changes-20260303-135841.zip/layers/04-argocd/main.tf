# ── WAF (conditional) ────────────────────────────────────────────────────────
module "waf" {
  count  = var.enable_waf ? 1 : 0
  source = "../../modules/waf-alb"

  name_prefix = "${local.cluster_name}-devops"
}

locals {
  # Resolve WAF ACL ARN: use module output if WAF is enabled, otherwise use
  # the pass-through variable (allows external WAF ARN injection)
  resolved_waf_acl_arn = var.enable_waf ? module.waf[0].web_acl_arn : var.waf_acl_arn
}

# ── ArgoCD Helm release ─────────────────────────────────────────────────────
module "helm" {
  source           = "../../modules/helm-release"
  release_name     = "argocd"
  namespace        = var.namespace
  chart_repository = "https://argoproj.github.io/argo-helm"
  chart_name       = "argo-cd"
  chart_version    = var.chart_version
  values           = local.helm_values
  timeout          = 900
}
