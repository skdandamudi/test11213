resource "helm_release" "this" {
  name             = var.release_name
  namespace        = var.namespace
  create_namespace = false

  repository = var.chart_repository
  chart      = var.chart_name
  version    = var.chart_version

  values = var.values
  timeout = var.timeout
}
