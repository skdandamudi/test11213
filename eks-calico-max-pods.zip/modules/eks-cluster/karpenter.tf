# ─────────────────────────────────────────────────────────────────────────────
# Karpenter infrastructure — controller IAM role (IRSA), node instance profile,
# SQS interruption queue, EventBridge rules, discovery tags, EKS access entry.
#
# All resources are conditional on var.karpenter_enabled.
# The Helm chart for Karpenter is deployed in a downstream layer.
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
# Instance profile for Karpenter-launched nodes (uses existing node IAM role)
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_iam_instance_profile" "karpenter" {
  count = var.karpenter_enabled ? 1 : 0
  name  = "${var.cluster_name}-karpenter-node"
  role  = aws_iam_role.node.name
}

# ─────────────────────────────────────────────────────────────────────────────
# EKS access entry — lets Karpenter-launched nodes join the cluster
# (managed node groups get this automatically; Karpenter nodes do not)
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_eks_access_entry" "karpenter_node" {
  count         = var.karpenter_enabled ? 1 : 0
  cluster_name  = aws_eks_cluster.this.name
  principal_arn = aws_iam_role.node.arn
  type          = "EC2_LINUX"
}

# ─────────────────────────────────────────────────────────────────────────────
# Karpenter controller IAM role (IRSA)
# ─────────────────────────────────────────────────────────────────────────────
locals {
  karpenter_namespace       = "kube-system"
  karpenter_service_account = "karpenter"
  oidc_issuer_host          = var.karpenter_enabled ? replace(aws_eks_cluster.this.identity[0].oidc[0].issuer, "https://", "") : ""
}

data "aws_iam_policy_document" "karpenter_assume" {
  count = var.karpenter_enabled ? 1 : 0

  statement {
    actions = ["sts:AssumeRoleWithWebIdentity"]

    principals {
      type        = "Federated"
      identifiers = [aws_iam_openid_connect_provider.cluster.arn]
    }

    condition {
      test     = "StringEquals"
      variable = "${local.oidc_issuer_host}:sub"
      values   = ["system:serviceaccount:${local.karpenter_namespace}:${local.karpenter_service_account}"]
    }

    condition {
      test     = "StringEquals"
      variable = "${local.oidc_issuer_host}:aud"
      values   = ["sts.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "karpenter_controller" {
  count              = var.karpenter_enabled ? 1 : 0
  name               = "${var.cluster_name}-karpenter-controller"
  assume_role_policy = data.aws_iam_policy_document.karpenter_assume[0].json
}

# ─────────────────────────────────────────────────────────────────────────────
# Karpenter controller IAM policy
# ─────────────────────────────────────────────────────────────────────────────

data "aws_iam_policy_document" "karpenter_controller" {
  count = var.karpenter_enabled ? 1 : 0

  # ── EC2 read-only (all resources) ──────────────────────────────────────────
  statement {
    sid = "AllowEC2ReadActions"
    actions = [
      "ec2:DescribeAvailabilityZones",
      "ec2:DescribeImages",
      "ec2:DescribeInstances",
      "ec2:DescribeInstanceTypeOfferings",
      "ec2:DescribeInstanceTypes",
      "ec2:DescribeLaunchTemplates",
      "ec2:DescribeSecurityGroups",
      "ec2:DescribeSpotPriceHistory",
      "ec2:DescribeSubnets",
    ]
    resources = ["*"]
  }

  # ── EC2 write — scoped to cluster-owned resources ──────────────────────────
  statement {
    sid = "AllowEC2WriteActions"
    actions = [
      "ec2:CreateFleet",
      "ec2:CreateLaunchTemplate",
      "ec2:CreateTags",
      "ec2:DeleteLaunchTemplate",
      "ec2:RunInstances",
      "ec2:TerminateInstances",
    ]
    resources = ["*"]
    condition {
      test     = "StringEquals"
      variable = "aws:RequestTag/karpenter.sh/discovery"
      values   = [var.cluster_name]
    }
  }

  # Allow terminating instances that already carry the cluster tag
  statement {
    sid       = "AllowEC2TerminateTagged"
    actions   = ["ec2:TerminateInstances"]
    resources = ["*"]
    condition {
      test     = "StringEquals"
      variable = "ec2:ResourceTag/karpenter.sh/discovery"
      values   = [var.cluster_name]
    }
  }

  # CreateTags on RunInstances (initial tagging)
  statement {
    sid       = "AllowEC2CreateTagsOnRun"
    actions   = ["ec2:CreateTags"]
    resources = ["arn:${local.partition}:ec2:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:*"]
    condition {
      test     = "StringEquals"
      variable = "ec2:CreateAction"
      values   = ["RunInstances", "CreateFleet", "CreateLaunchTemplate"]
    }
  }

  # ── Instance profiles ──────────────────────────────────────────────────────
  statement {
    sid = "AllowInstanceProfileActions"
    actions = [
      "iam:AddRoleToInstanceProfile",
      "iam:CreateInstanceProfile",
      "iam:DeleteInstanceProfile",
      "iam:GetInstanceProfile",
      "iam:RemoveRoleFromInstanceProfile",
      "iam:TagInstanceProfile",
    ]
    resources = ["*"]
  }

  # ── Pass the node role to EC2 ──────────────────────────────────────────────
  statement {
    sid       = "AllowPassNodeRole"
    actions   = ["iam:PassRole"]
    resources = [aws_iam_role.node.arn]
  }

  # ── EKS ────────────────────────────────────────────────────────────────────
  statement {
    sid       = "AllowEKSDescribeCluster"
    actions   = ["eks:DescribeCluster"]
    resources = [aws_eks_cluster.this.arn]
  }

  # ── SSM — AMI discovery ────────────────────────────────────────────────────
  statement {
    sid       = "AllowSSMReadActions"
    actions   = ["ssm:GetParameter"]
    resources = ["arn:${local.partition}:ssm:${data.aws_region.current.name}::parameter/aws/service/*"]
  }

  # ── Pricing ────────────────────────────────────────────────────────────────
  statement {
    sid       = "AllowPricingReadActions"
    actions   = ["pricing:GetProducts"]
    resources = ["*"]
  }

  # ── SQS — interruption handling ────────────────────────────────────────────
  statement {
    sid = "AllowSQSActions"
    actions = [
      "sqs:DeleteMessage",
      "sqs:GetQueueAttributes",
      "sqs:GetQueueUrl",
      "sqs:ReceiveMessage",
    ]
    resources = [aws_sqs_queue.karpenter[0].arn]
  }
}

resource "aws_iam_policy" "karpenter_controller" {
  count  = var.karpenter_enabled ? 1 : 0
  name   = "${var.cluster_name}-karpenter-controller"
  policy = data.aws_iam_policy_document.karpenter_controller[0].json
}

resource "aws_iam_role_policy_attachment" "karpenter_controller" {
  count      = var.karpenter_enabled ? 1 : 0
  role       = aws_iam_role.karpenter_controller[0].name
  policy_arn = aws_iam_policy.karpenter_controller[0].arn
}

# ─────────────────────────────────────────────────────────────────────────────
# SQS queue — Karpenter interruption handling
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_sqs_queue" "karpenter" {
  count                     = var.karpenter_enabled ? 1 : 0
  name                      = "${var.cluster_name}-karpenter"
  message_retention_seconds = 300
  sqs_managed_sse_enabled   = true
}

data "aws_iam_policy_document" "karpenter_sqs" {
  count = var.karpenter_enabled ? 1 : 0

  statement {
    sid     = "AllowEventBridgePublish"
    actions = ["sqs:SendMessage"]

    principals {
      type        = "Service"
      identifiers = ["events.amazonaws.com"]
    }

    resources = [aws_sqs_queue.karpenter[0].arn]
  }
}

resource "aws_sqs_queue_policy" "karpenter" {
  count     = var.karpenter_enabled ? 1 : 0
  queue_url = aws_sqs_queue.karpenter[0].id
  policy    = data.aws_iam_policy_document.karpenter_sqs[0].json
}

# ─────────────────────────────────────────────────────────────────────────────
# EventBridge rules → SQS
# ─────────────────────────────────────────────────────────────────────────────

# Spot Instance Interruption Warning
resource "aws_cloudwatch_event_rule" "karpenter_spot_interruption" {
  count       = var.karpenter_enabled ? 1 : 0
  name        = "${var.cluster_name}-karpenter-spot-interruption"
  description = "EC2 Spot Instance Interruption Warning → Karpenter"

  event_pattern = jsonencode({
    source      = ["aws.ec2"]
    detail-type = ["EC2 Spot Instance Interruption Warning"]
  })
}

resource "aws_cloudwatch_event_target" "karpenter_spot_interruption" {
  count     = var.karpenter_enabled ? 1 : 0
  rule      = aws_cloudwatch_event_rule.karpenter_spot_interruption[0].name
  target_id = "KarpenterSpotInterruption"
  arn       = aws_sqs_queue.karpenter[0].arn
}

# Instance Rebalance Recommendation
resource "aws_cloudwatch_event_rule" "karpenter_rebalance" {
  count       = var.karpenter_enabled ? 1 : 0
  name        = "${var.cluster_name}-karpenter-rebalance"
  description = "EC2 Instance Rebalance Recommendation → Karpenter"

  event_pattern = jsonencode({
    source      = ["aws.ec2"]
    detail-type = ["EC2 Instance Rebalance Recommendation"]
  })
}

resource "aws_cloudwatch_event_target" "karpenter_rebalance" {
  count     = var.karpenter_enabled ? 1 : 0
  rule      = aws_cloudwatch_event_rule.karpenter_rebalance[0].name
  target_id = "KarpenterRebalance"
  arn       = aws_sqs_queue.karpenter[0].arn
}

# Instance State-change Notification
resource "aws_cloudwatch_event_rule" "karpenter_state_change" {
  count       = var.karpenter_enabled ? 1 : 0
  name        = "${var.cluster_name}-karpenter-state-change"
  description = "EC2 Instance State-change Notification → Karpenter"

  event_pattern = jsonencode({
    source      = ["aws.ec2"]
    detail-type = ["EC2 Instance State-change Notification"]
  })
}

resource "aws_cloudwatch_event_target" "karpenter_state_change" {
  count     = var.karpenter_enabled ? 1 : 0
  rule      = aws_cloudwatch_event_rule.karpenter_state_change[0].name
  target_id = "KarpenterStateChange"
  arn       = aws_sqs_queue.karpenter[0].arn
}

# AWS Health Event for EC2
resource "aws_cloudwatch_event_rule" "karpenter_health" {
  count       = var.karpenter_enabled ? 1 : 0
  name        = "${var.cluster_name}-karpenter-health"
  description = "AWS Health Event (EC2) → Karpenter"

  event_pattern = jsonencode({
    source      = ["aws.health"]
    detail-type = ["AWS Health Event"]
    detail = {
      service = ["EC2"]
    }
  })
}

resource "aws_cloudwatch_event_target" "karpenter_health" {
  count     = var.karpenter_enabled ? 1 : 0
  rule      = aws_cloudwatch_event_rule.karpenter_health[0].name
  target_id = "KarpenterHealth"
  arn       = aws_sqs_queue.karpenter[0].arn
}

# ─────────────────────────────────────────────────────────────────────────────
# Discovery tags — Karpenter uses these to find subnets and security groups
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_ec2_tag" "karpenter_subnet" {
  count       = var.karpenter_enabled ? length(var.subnet_ids) : 0
  resource_id = var.subnet_ids[count.index]
  key         = "karpenter.sh/discovery"
  value       = var.cluster_name
}

resource "aws_ec2_tag" "karpenter_security_group" {
  count       = var.karpenter_enabled ? 1 : 0
  resource_id = aws_security_group.cluster.id
  key         = "karpenter.sh/discovery"
  value       = var.cluster_name
}
