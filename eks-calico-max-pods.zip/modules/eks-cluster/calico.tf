# ─────────────────────────────────────────────────────────────────────────────
# Calico CNI — deployed via Tigera operator Helm chart
#
# Two modes:
#   policy-only : Keep VPC CNI for networking, use Calico for network policy
#   cni         : Replace VPC CNI entirely with Calico networking + policy
#
# CNI mode execution flow:
#   1. Cluster created — EKS auto-installs aws-node DaemonSet (self-managed VPC CNI)
#   2. VPC CNI managed addon NOT created (existing logic in main.tf)
#   3. Node group created — nodes join, self-managed aws-node runs, nodes become Ready
#   4. null_resource.remove_vpc_cni — kubectl deletes the aws-node DaemonSet
#   5. Calico Helm release — operator + calico-node replace VPC CNI
#
# Security groups: The EKS-managed cluster security group (auto-created by EKS)
# allows all traffic between nodes by default, which covers Calico encapsulation
# ports (VXLAN UDP/4789, IPIP protocol 4, BGP TCP/179) without extra rules.
# ─────────────────────────────────────────────────────────────────────────────

# ── Remove self-managed VPC CNI for Calico CNI mode ─────────────────────────
# EKS pre-installs the VPC CNI as a self-managed addon (aws-node DaemonSet in
# kube-system) on every new cluster. When using Calico as the CNI, this
# DaemonSet must be deleted before Calico is installed to avoid conflicts.
resource "null_resource" "remove_vpc_cni" {
  count = var.calico_enabled && var.calico_mode == "cni" ? 1 : 0

  provisioner "local-exec" {
    interpreter = ["bash", "-euo", "pipefail", "-c"]
    command     = <<-EOT
      aws eks update-kubeconfig \
        --name ${aws_eks_cluster.this.name} \
        --region ${data.aws_region.current.name} \
        --kubeconfig /tmp/kubeconfig-${aws_eks_cluster.this.name}
      export KUBECONFIG="/tmp/kubeconfig-${aws_eks_cluster.this.name}"
      echo "Waiting for nodes to become Ready..."
      kubectl wait --for=condition=Ready node --all --timeout=300s
      echo "Deleting aws-node DaemonSet..."
      kubectl delete daemonset aws-node -n kube-system --ignore-not-found=true
      rm -f /tmp/kubeconfig-${aws_eks_cluster.this.name}
      echo "VPC CNI (aws-node) removed successfully."
    EOT
  }

  triggers = {
    cluster_endpoint = aws_eks_cluster.this.endpoint
  }

  depends_on = [aws_eks_cluster.this, aws_eks_node_group.this]
}

# ── Launch template for Calico CNI max-pods override ─────────────────────────
# When Calico replaces the VPC CNI, nodes still boot with a kubelet --max-pods
# limit derived from ENI capacity. This launch template injects user data to
# override that limit since Calico manages its own IPAM via overlay.

locals {
  use_calico_launch_template = (
    var.calico_enabled &&
    var.calico_mode == "cni" &&
    var.managed_node_group_enabled &&
    var.calico_max_pods_per_node > 0
  )

  # AL2023 nodeadm user data (MIME multipart merged by EKS)
  calico_userdata_al2023 = <<-MIME
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="BOUNDARY"

--BOUNDARY
Content-Type: application/node.eks.aws

apiVersion: node.eks.aws/v1alpha1
kind: NodeConfig
spec:
  kubelet:
    config:
      maxPods: ${var.calico_max_pods_per_node}

--BOUNDARY--
MIME

  # AL2 pre-bootstrap user data (runs before EKS-appended bootstrap.sh)
  calico_userdata_al2 = <<-SHELL
#!/bin/bash
# Override max-pods for all instance types (Calico CNI manages its own IPAM)
sed -i 's/\([a-z0-9.-]*\) [0-9]*/\1 ${var.calico_max_pods_per_node}/' /etc/eks/eni-max-pods.txt
SHELL

  calico_node_userdata = (
    local.use_calico_launch_template
    ? base64encode(startswith(var.node_ami_type, "AL2023")
        ? local.calico_userdata_al2023
        : local.calico_userdata_al2)
    : null
  )
}

resource "aws_launch_template" "calico_cni" {
  count       = local.use_calico_launch_template ? 1 : 0
  name_prefix = "${var.cluster_name}-calico-"

  block_device_mappings {
    device_name = "/dev/xvda"
    ebs {
      volume_size = var.node_disk_size
      volume_type = "gp3"
      encrypted   = true
    }
  }

  user_data = local.calico_node_userdata

  tag_specifications {
    resource_type = "instance"
    tags = merge(var.tags, {
      Name = "${var.cluster_name}-calico-node"
    })
  }

  tags = var.tags

  lifecycle {
    precondition {
      condition     = !startswith(var.node_ami_type, "BOTTLEROCKET")
      error_message = "Calico CNI max-pods override does not support Bottlerocket AMIs (TOML user data format). Set calico_max_pods_per_node = 0 to disable the override when using Bottlerocket."
    }
  }
}

locals {
  # Base installation config varies by Calico mode
  calico_installation_base = var.calico_mode == "policy-only" ? {
    kubernetesProvider = "EKS"
    cni                = { type = "AmazonVPC" }
    calicoNetwork      = { linuxPolicyOnly = true }
  } : {
    kubernetesProvider = "EKS"
    cni                = { type = "Calico" }
    calicoNetwork = {
      bgp = var.calico_encapsulation == "VXLAN" ? "Disabled" : "Enabled"
      ipPools = [{
        cidr          = var.calico_pod_cidr
        encapsulation = var.calico_encapsulation
      }]
    }
  }

  # Registry + pull secret overrides (merged into installation when set)
  calico_registry_overrides = merge(
    var.calico_image_registry != "" ? { registry = var.calico_image_registry } : {},
    length(var.calico_image_pull_secrets) > 0 ? {
      imagePullSecrets = [for s in var.calico_image_pull_secrets : { name = s }]
    } : {},
  )

  # Final Helm values map
  calico_values = merge(
    {
      installation = merge(local.calico_installation_base, local.calico_registry_overrides)
    },
    # Operator image registry (separate top-level key in chart values)
    var.calico_image_registry != "" ? {
      tigeraOperator = { registry = var.calico_image_registry }
    } : {},
  )
}

resource "helm_release" "calico" {
  count = var.calico_enabled ? 1 : 0

  name             = "calico"
  repository       = var.calico_chart_repository
  chart            = "tigera-operator"
  version          = var.calico_version
  namespace        = "tigera-operator"
  create_namespace = true

  values = [yamlencode(local.calico_values)]

  depends_on = [
    aws_eks_cluster.this,
    aws_eks_node_group.this,
    null_resource.remove_vpc_cni,
  ]
}
